daniel = 5

taille = -daniel

print(taille)